package com.oracle.oep.demo.simulator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DemoSimulator {

	private static Log log_ = LogFactory.getLog(DemoSimulator.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("Simulator Started!");
		
		SmartMeterSimulator sim1 = new SmartMeterSimulator();
	    Thread t1 = new Thread(sim1);
	    t1.start();
	    
	    if(log_.isInfoEnabled()) {
	    	log_.info("Smart Meter Simulator Started!");
		}
	     
	}
	
	
}
