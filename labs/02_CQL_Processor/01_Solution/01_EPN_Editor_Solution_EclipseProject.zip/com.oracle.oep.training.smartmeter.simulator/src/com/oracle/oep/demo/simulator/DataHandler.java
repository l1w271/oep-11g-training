package com.oracle.oep.demo.simulator;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.oracle.oep.demo.jaxb.event.*;

public class DataHandler {
  
  private Map<String,Meter> data = new HashMap<String,Meter>();
  private Map<Integer,Meter> iData = new HashMap<Integer,Meter>();
  private int index = 0 ;
  private Random randomGenerator = new Random();
		
  private Log log_ = LogFactory.getLog(DataHandler.class);
  private JAXBContext jaxbContext_;
  private Unmarshaller unmarshaller_;
 
  

@SuppressWarnings("rawtypes")
public DataHandler(String srcfile) throws Exception {
	
	initJaxb(); 	    	  	      

	File f = new File(srcfile);
	
	try {
		
		Object refData = unmarshaller_.unmarshal(f);			
		if(refData instanceof JAXBElement) {
			
			String substationName = "";
			String transformerId = "";
			
			Object element = ((JAXBElement) refData).getValue();
			if (element instanceof Substation) {
				Substation s = (Substation) element;
				substationName = s.getName();
				System.out.println("Reading data for substation:" + substationName);
				for(Transformer t : s.getTransformer() ) {				
					transformerId = t.getId();
					for(Meter m : t.getMeter() ) {				
						m.setTransformerId(transformerId);
						addMeter(m);
					}
				}
			}
		} else {
			throw new IllegalStateException("Unexpected XML type.  Got:" + refData.getClass() + 
					" Expected:"+ Transformer.class.getName());
		}
	} catch (Exception e) {
		throw new IllegalStateException("Error processing product data!",e);
	}
	//log_.info("Product data loaded:" + data);       
   
  }
  
  public Meter getMeter(String id) {
    return (Meter)data.get(id);
  }
  
  public int getSize(){
	  return data.size();
  }
  
  public Meter getRandomMeter(){
	  Meter e = null ;
	  
	  int randomNumber = randomGenerator.nextInt(getSize());	  
	  e = iData.get(randomNumber);
  
	  return e ;
  }

  public Meter getMeterForIndex(int index){
	  Meter e = null ;
	  	  
	  e = iData.get(index);
  
	  return e ;
  }
  
  private synchronized void addMeter(Meter event){

	  data.put(event.getMeterId(), event);
      iData.put(index, event);      
	  index += 1 ;
      log_.info("There are " + getSize() + " meters loaded!" );
  }
  
  public synchronized void updateProductTable(Meter event){
	  String key = event.getMeterId() ;
	  if (data.containsKey(key)){
		  data.remove(key);
	  }
	  if (iData.containsKey(key)){
		  data.remove(key);
	  }
	  addMeter(event);
  }

  private void initJaxb() {
	try {
		jaxbContext_ = JAXBContext.newInstance(ObjectFactory.class.getPackage().getName());
		unmarshaller_ = jaxbContext_.createUnmarshaller();
	} catch (JAXBException e) {
		throw new RuntimeException("Could not init JAXB :" + e.getMessage(), e);
	}
	if(log_.isInfoEnabled()) {
		//log_.info("Initialized JAXB");
	}
  }
  
}

