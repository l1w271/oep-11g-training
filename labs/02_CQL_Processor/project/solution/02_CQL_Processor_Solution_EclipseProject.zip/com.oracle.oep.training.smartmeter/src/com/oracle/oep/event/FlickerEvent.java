package com.oracle.oep.event;

public class FlickerEvent {

	protected String meterId ;
	protected String flickerTime ;
	public String getMeterId() {
		return meterId;
	}
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}
	public String getFlickerTime() {
		return flickerTime;
	}
	public void setFlickerTime(String flickerTime) {
		this.flickerTime = flickerTime;
	}
	@Override
	public String toString() {
		return "FlickerEvent [meterId=" + meterId + ", flickerTime="
				+ flickerTime + "]";
	}
	
	
	
}
