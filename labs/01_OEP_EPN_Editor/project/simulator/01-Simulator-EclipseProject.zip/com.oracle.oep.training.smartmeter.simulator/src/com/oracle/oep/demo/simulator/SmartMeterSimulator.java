package com.oracle.oep.demo.simulator;

import java.util.Properties ;
import java.util.Random;
import java.io.FileInputStream ;
import java.io.FileNotFoundException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.oracle.oep.demo.jaxb.event.*;

public class SmartMeterSimulator implements Runnable {

	private static Log log_ = LogFactory.getLog(SmartMeterSimulator.class);
    private static Properties simProps ;

    private static String INPUT_XML_FILE = "sim_input.xml" ;

    private static DataHandler dh = null ;  

	private static int EVENT_NUMBER = 0 ;
	private static int NUMBER_EVENTS = 10 ;
	private static int MAX_WAIT_BETWEEN_EVENTS = 10 ;
	
	//private static String[] POSSIBLE_STATES = {"POWER_UP", "POWER_DOWN", "TAMPER_ALERT"};
	public static final String POWER_UP = "POWER_UP";
	public static final String POWER_DOWN = "POWER_DOWN";
	public static final String TAMPER = "TAMPER_ALERT";
	
	public void run() {
		
		start();
		
	}
    	
	public void start(){
		
		// load the properties
		loadProperties();
		//log_.debug("Loaded properties file!");
		setProperties();
		//log_.debug("Set properties!");
		
		// get the vehicles
		try {
			dh = new DataHandler(INPUT_XML_FILE);
		} catch (Exception e){
			log_.error("Could not load input from file: " + INPUT_XML_FILE );
			e.printStackTrace();
		}
		
		for (EVENT_NUMBER=1; EVENT_NUMBER<=NUMBER_EVENTS; EVENT_NUMBER++){

			//GET A METER
			Meter m = dh.getRandomMeter();
			
			MeterStateEvent state = new MeterStateEvent();			
			state.setMeterId(m.getMeterId());
			state.setTransformerId(m.getTransformerId());
			state.setCustomerType(m.getCustomerType());
			/*
			Random r1 = new Random();
		    int rs = r1.nextInt(POSSIBLE_STATES.length); 
			state.setState(POSSIBLE_STATES[rs]);
			*/

			DataGenerator gen = new DataGenerator(EVENT_NUMBER, state, simProps);
		    Thread t1 = new Thread(gen);
		    t1.start();
		    
		    Random r2 = new Random();
		    int wait = r2.nextInt(MAX_WAIT_BETWEEN_EVENTS); 
		    try {
		    	Thread.sleep(wait);
		    }
		    catch (Exception ex){
		    	//Interrupted exception
		    }
		}
		
		   // threadMessage("Waiting a little!");
		
		
		
	}


	/*
	//Display a message, preceded by the name of the current thread
    private static void threadMessage(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.format("%s: %s%n", threadName, message);
    }
	*/
	
	public void loadProperties(){
		
		simProps = new Properties();
		
		try {
			FileInputStream in = new FileInputStream("simulator.properties");
			simProps.load(in);
			in.close();		
		} 
		catch (FileNotFoundException nofile){
			System.out.println("Simulator properties file not found!");
		}
		catch (Exception ex){
			ex.printStackTrace();
			System.out.println("Exception occured retreiving the simulator properties!");
		}
		
			
	}
	
	public void setProperties(){
		
		NUMBER_EVENTS = Integer.valueOf(simProps.getProperty("number.events")).intValue();
		MAX_WAIT_BETWEEN_EVENTS = Integer.valueOf(simProps.getProperty("wait.between.events")).intValue();		

	}

	
	
	
}
