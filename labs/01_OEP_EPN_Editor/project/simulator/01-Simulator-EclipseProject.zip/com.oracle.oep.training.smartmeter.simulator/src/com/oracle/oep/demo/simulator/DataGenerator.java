package com.oracle.oep.demo.simulator;

import java.io.FileInputStream;
import java.io.StringWriter;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.Random;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import weblogic.jms.extensions.WLQueueSession;
import weblogic.jms.extensions.WLSession;

import com.oracle.oep.demo.jaxb.event.ObjectFactory;
import com.oracle.oep.demo.jaxb.event.MeterStateEvent;

public class DataGenerator implements Runnable {

	private static Log log_ = LogFactory.getLog(DataGenerator.class);
	
	private JAXBContext jaxbContext_;
	//private Unmarshaller unmarshaller_;
	private Marshaller marshaller_ ;
	
	private QueueConnectionFactory qconFactory;
    private QueueConnection qcon;
    private QueueSession qsession;
    private QueueSender qsender;
    private Queue queue;
    private TextMessage msg;
    
    private String WLS_QUEUE_NAME = "jms/demoQueue" ;
    private String WLS_CONN_FACTORY_NAME = "jms/QueueConnectionFactory" ; 
    
    private MeterStateEvent state ;
    private int FLICKER_PERCENT = 50 ;
    private int TAMPER_PERCENT = 10 ;
    
    public DataGenerator(int num, MeterStateEvent state, Properties props) {
		super();
		this.state = state;
		setProperties(props);
	}
	
	
	public void run() {
		
		//initialize JAXB context
		initJaxb();
						
		// send the events
		sendJMSEvents() ;
		
	}
	
	
	public void setProperties(Properties simProps){
		
		WLS_QUEUE_NAME = simProps.getProperty("queue.name");
		WLS_CONN_FACTORY_NAME = simProps.getProperty("connection.factory.name");
		FLICKER_PERCENT = Integer.valueOf(simProps.getProperty("flicker.percent")).intValue();
		TAMPER_PERCENT = Integer.valueOf(simProps.getProperty("tamper.percent")).intValue();
			    
	}
	
	//Display a message, preceded by the name of the current thread
    static void threadMessage(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.format("%s: %s%n", threadName, message);
    }
	
	@SuppressWarnings("rawtypes")
	private String createXMLMessage(JAXBElement element) {
		try {			
			
			StringWriter sw = new StringWriter();
			marshaller_.marshal(element, sw);
			//TESTING: show the xml string on the console
			//System.out.println(sw.toString());
			return sw.toString();		
		}
		catch (JAXBException jaxbException) {
			//throw new Exception("JAXB unmarshalling failure:", jaxbException);
			jaxbException.printStackTrace();
			return null ;
		}
	}

	
    public String createEventXML(){
    	
    	String EventMessage = null ;
 			
		ObjectFactory factory = new ObjectFactory();		
		JAXBElement<MeterStateEvent> xElement = factory.createMeterStateEvent(state);	
		
		// CREATE THE XML 
		EventMessage = createXMLMessage(xElement); 	
    	
		// SHOW THE MESSAGE
		System.out.println(EventMessage);
    	
    	return EventMessage ;
    	
    }
    
    public void wait(int max_time){
	    Random r = new Random();
	    int wait = r.nextInt(max_time); 
	    try {
	    	Thread.sleep(wait);
	    }
	    catch (Exception ex){
	    	//Interrupted exception
	    }
    }
    
    public void sendJMSEvents(){
		
		try {

			Properties namingProps = new Properties();
			FileInputStream in = new FileInputStream("etc/naming.props");
			namingProps.load(in);
			//log_.info("Loaded naming.props file!");
			in.close();

			Context jmsContext = new InitialContext(namingProps);
			//log_.info("Connection Factory Name: " + WLS_CONN_FACTORY_NAME); 
			qconFactory = (QueueConnectionFactory) jmsContext.lookup(WLS_CONN_FACTORY_NAME);
			
			qcon = (QueueConnection)qconFactory.createQueueConnection();

			qsession = (WLQueueSession)qcon.createQueueSession(false, WLSession.AUTO_ACKNOWLEDGE);

			//log_.info("Queue Name: " + WLS_QUEUE_NAME);
			queue = (Queue) jmsContext.lookup(WLS_QUEUE_NAME);

			qsender = qsession.createSender(queue);
			//log_.info("Created a queue sender!");
	    	
	    	//POWER DOWN
			sendPowerDownEvent();
	    	sendPowerUpEvent();
	    	
			Random a = new Random();
	    	int flick = a.nextInt(100);
	    	if (flick < this.FLICKER_PERCENT){
	    		sendPowerUpEvent();
	    	}
						
	    	//TAMPER
			Random b = new Random();
	    	int tamper = b.nextInt(100);
	    	if (tamper < this.TAMPER_PERCENT){
	    		sendTamperEvent();
	    	}
				    
		} catch (JMSException jmse){
			jmse.printStackTrace();
			System.out.println("JMS Exception");
		} catch (Exception e){
			e.printStackTrace();
			System.out.println("non-JMS Exception!");
		} finally {
			close();
		}
    	    	
	}
 
    public void sendPowerUpEvent() {
	   	
    	state.setState(SmartMeterSimulator.POWER_UP);
    	state.setStatusTime(getDate().toString());
    	sendEventXML();
    	
    	threadMessage("POWER_UP! Meter ID:" + state.getMeterId() + " TIME: " + state.getStatusTime() + "\n");
    } 
    
    public void sendPowerDownEvent() {
    	   	
    	state.setState(SmartMeterSimulator.POWER_DOWN);
    	state.setStatusTime(getDate().toString());
    	sendEventXML();

    	threadMessage("POWER_DOWN! Meter ID:" + state.getMeterId() + " TIME: " + state.getStatusTime() + "\n");
    	
    }
    
    public void sendTamperEvent() {
	   	
    	state.setState(SmartMeterSimulator.TAMPER);
    	state.setStatusTime(getDate().toString());
    	sendEventXML();

    	threadMessage("TAMPER! Meter ID:" + state.getMeterId() + " TIME: " + state.getStatusTime() + "\n");
    	
    }
    
    
    
    private void sendEventXML() {
    	
    	try {
    	
	    	String EventMessage = null ;
	    	EventMessage = createEventXML();
	    	msg = qsession.createTextMessage();
		    msg.setText(EventMessage);	
		    qsender.send(msg);
		    qcon.start();	
    	
    	} catch (JMSException jmsex){
    		if (state != null){
    			log_.error("JMS Exception! Meter ID: " + state.getMeterId() + " State: " + state.getState() );
    		} else {
    			log_.error("JMS Exception! Meter ID is null.");
    		}
    		
    		jmsex.printStackTrace();
    			
    	}
    	
    }
    
    

    public void close()
    {
    	try {
	    	qsender.close();
		    qsession.close();
		    qcon.close();
    	} catch (JMSException jmse){
			jmse.printStackTrace();
			System.out.println("JMS Exception during closing!");
		} catch (Exception e){
			e.printStackTrace();
			System.out.println("Non-JMS Exception during closing!");
		}
    }

	 private XMLGregorianCalendar getDate() {	
	    	try {	    
	    		return DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar());	
	    	} 
	    	catch (DatatypeConfigurationException e) {	    
	    		throw new Error(e); 
	    	}
	    }
	
  private void initJaxb() {
		try {
			jaxbContext_ = JAXBContext.newInstance(ObjectFactory.class.getPackage().getName());
			//unmarshaller_ = jaxbContext_.createUnmarshaller();
			marshaller_ = jaxbContext_.createMarshaller();
			marshaller_.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

		} catch (JAXBException e) {
			throw new RuntimeException("Could not init JAXB :" + e.getMessage(), e);
		}
		if(log_.isInfoEnabled()) {
			//log_.info("Initialized JAXB");
		}
	  }

	
	
}
