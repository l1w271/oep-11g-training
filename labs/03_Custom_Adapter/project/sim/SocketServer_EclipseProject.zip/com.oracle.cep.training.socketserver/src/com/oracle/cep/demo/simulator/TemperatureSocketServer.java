/* (c) 2006-2007 BEA Systems, Inc.  All rights reserved. */
package com.oracle.cep.demo.simulator;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

import java.io.File;

public class TemperatureSocketServer {

	private static String INPUT_FILE = "datafeed.properties";
	
	public static void main(String[] args) {
		int port = 9000;
		Properties properties = new Properties();

		try {
			System.out.println("Reading properties from file \"" + INPUT_FILE
					+ "\":");
			properties.load(new FileInputStream(INPUT_FILE));
			System.out.println(properties);
			port = Integer.parseInt(properties.getProperty("datafeed.port"));
			ServerSocket server = new ServerSocket(port);
			System.out
					.println("Accepting connections on port " + port + " ...");
			while (true) {
				Socket socket = server.accept();
				Thread t = new FileReaderThread(socket, properties);
				t.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

class FileReaderThread extends Thread {
	private Socket socket;

	private Properties properties;

	public FileReaderThread(Socket socket, Properties properties) {
		this.socket = socket;
		this.properties = properties;
		System.out.println("Connection accepted: " + socket);
	}

	byte[] data;
	
	private long lastTimestamp;
	
	private static long INTERVAL = 50000;

	private long eventCounter = 0;
	
	public void run() {
		FileReader fr;

		long delay = (long) (1000.0 / Double.parseDouble(properties
				.getProperty("datafeed.throughput")));
		try {
			eventCounter = 0;
			lastTimestamp = System.currentTimeMillis();		
			
			OutputStream out = new BufferedOutputStream(socket
					.getOutputStream());

			fr = new FileReader(new File(properties.getProperty("datafeed.file")));
			BufferedReader br = new BufferedReader(fr);

			while (!socket.isClosed()) {

				String line = br.readLine();
				if (line != null && line.length() > 0) {
					line += '\n';
					data = line.getBytes();
				} else {
					br.close();
					if (Boolean.parseBoolean(properties
							.getProperty("datafeed.loop"))) {
						System.out
								.println("end of data file reached, continuing from the beginning");
						fr = new FileReader(new File(properties
								.getProperty("datafeed.file")));
						br = new BufferedReader(fr);
						line = br.readLine();
						line += '\n';
						data = line.getBytes();
					} else {
						System.out
								.println("end of data file reached, finishing");
						break;
					}
				}

				out.write(data);
				out.flush();
				eventCounter++;
				if (eventCounter % INTERVAL == 0){
					long now = System.currentTimeMillis();
					System.out.println("Throughput (msg per second): " + (long)((double)INTERVAL / ((double)(now - lastTimestamp)/1000.0)));
					lastTimestamp = now;
				}				
				
				if (delay > 0) {
					Thread.sleep(delay);
				}
			}
			socket.close();
			System.out.println("Connection closed:   " + socket);
		} catch (Exception e) {
			System.out.println("Connection closed:   " + socket);
		}
	}
}
